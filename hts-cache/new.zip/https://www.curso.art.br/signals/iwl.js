<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">

    <style>
        body {
            font-family: Arial, Helvetica, sans-serif;
            text-align: center;
        }
    </style>

    <title>404 - Página não encontrada</title>

</head>

<body>
<h1>404</h1>
Esta página não existe
</body>
</html>
